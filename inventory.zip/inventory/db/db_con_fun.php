<?php
class connection{
    public $user="dgpspdpi_farith";
    public $pass="Farith@1990";
    
    public function connect(){
        
        return new PDO("mysql:host={localhost};dbname={dgpspdpi_inventory}", $user,$pass);
    }
    

}
?>