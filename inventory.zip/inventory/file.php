 <?php 
 
 echo $time= date("Y/m/d").' 00:00:00';
 echo "<br>";
echo $time2= date("Y/m/d").' 23:59:59';
                
                ?>